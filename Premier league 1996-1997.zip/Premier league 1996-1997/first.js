let data = [
    { "POS" : 1, "Name" : "Man Utd" , "W" : 21 , "D" : 12 , "L" : 5 , "PTS" : 75},
    { "POS" : 2, "Name" : "Newcastle" , "W" : 19 , "D" : 11 , "L" : 8 , "PTS" : 68},
    { "POS" : 3, "Name" : "Arsenal" , "W" : 19 , "D" : 11 , "L" : 8 , "PTS" : 68},
    { "POS" : 4, "Name" : "Liverpool" , "W" : 19 , "D" : 11 , "L" : 8 , "PTS" : 68},
    { "POS" : 5, "Name" : "Aston Villa" , "W" : 17 , "D" : 10 , "L" : 11 , "PTS" : 61},
    { "POS" : 6, "Name" : "Chelsea" , "W" : 16 , "D" : 11 , "L" : 11 , "PTS" : 59},
    { "POS" : 7, "Name" : "Wednesday" , "W" : 14 , "D" : 15 , "L" : 9 , "PTS" : 57},
    { "POS" : 8, "Name" : "Milton Keynes" , "W" : 15 , "D" : 11 , "L" : 12 , "PTS" : 56},
    { "POS" : 9, "Name" : "Leicester City" , "W" : 12 , "D" : 11 , "L" : 15 , "PTS" : 47},
    { "POS" : 10, "Name" : "Tottenham" , "W" : 13 , "D" : 7 , "L" : 18 , "PTS" : 46},
    { "POS" : 11, "Name" : "Leeds Utd" , "W" : 11 , "D" : 13 , "L" : 14 , "PTS" : 46},
    { "POS" : 12, "Name" : "Derby County" , "W" : 11 , "D" : 13 , "L" : 14 , "PTS" : 46},
    { "POS" : 13, "Name" : "Blackburn" , "W" : 9 , "D" : 15 , "L" : 14 , "PTS" : 42},
    { "POS" : 14, "Name" : "West Ham" , "W" : 10 , "D" : 12 , "L" : 16 , "PTS" : 42},
    { "POS" : 15, "Name" : "Everton" , "W" : 10 , "D" : 12 , "L" : 16 , "PTS" : 42},
    { "POS" : 16, "Name" : "Southampton" , "W" : 10 , "D" : 11 , "L" : 17 , "PTS" : 41},
    { "POS" : 17, "Name" : "Coventry City" , "W" : 9 , "D" : 14 , "L" : 15 , "PTS" : 41},
    { "POS" : 18, "Name" : "Sunderland" , "W" : 10 , "D" : 10 , "L" : 18 , "PTS" : 40},
    { "POS" : 19, "Name" : "Middlesbrough" , "W" : 10 , "D" : 12 , "L" : 16 , "PTS" : 39},
    { "POS" : 20, "Name" : "Notts Forest" , "W" : 6 , "D" : 16 , "L" : 16 , "PTS" : 34}
]

function tabulate(data, columns) {
    let table = d3.select('body').append('table')
    let thead = table.append('thead')
    let	tbody = table.append('tbody');


    thead.append('tr')
        .selectAll('th')
        .data(columns).enter()
        .append('th')
        .text(function (column) { return column; });


    let rows = tbody.selectAll('tr')
        .data(data)
        .enter()
        .append('tr');


    rows.selectAll('td')
        .data(function (row) {
            return columns.map(function (column) {
                return {column: column, value: row[column]};
            });
        })
        .enter()
        .append('td')
        .text(function (d) { return d.value; });
    return table;
}


tabulate(data, ['POS', 'Name', 'W' , 'D' , 'L' , 'PTS']);
